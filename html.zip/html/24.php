<?php
shell_exec('rm size.txt'); // save wheel size as stated size to wheel file. used once button is pressed
shell_exec('echo "24" >> size.txt');
header('Location: index.html');
?>
