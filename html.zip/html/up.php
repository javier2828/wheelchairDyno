<?php
$f = fopen("/var/www/html/level.txt", "r");
$line = fgets($f, 2); // get state of level
fclose($f);
// run script once button is pressed
if ($line == "1" ){ // if state is 1 then save state 2 on level text
	shell_exec('rm level.txt');
	shell_exec('echo "2" >> level.txt');
}
if ($line == "2"  ){ // do the same for other states
	shell_exec('rm level.txt');
	shell_exec('echo "3" >> level.txt');
}
if ($line == "3" ){
	shell_exec('rm level.txt');
	shell_exec('echo "4" >> level.txt');
}
if ($line == "4" ){
	shell_exec('rm level.txt');
	shell_exec('echo "5" >> level.txt');
}
if ($line == "5" ){
	shell_exec('rm level.txt');
	shell_exec('echo "6" >> level.txt');
}
if ($line == "6" ){
	shell_exec('rm level.txt');
	shell_exec('echo "1" >> level.txt');
}

?>
