<html>
    <head>
        <title>File Listing</title>
        </head>
        <body>
            <?php
            $directory = '/home/pi/Desktop/data';
            
            if($handle = opendir($directory.'/')){
                echo "Looking inside '$directory'" . '<br>';
            }
            
            while($file = readdir($handle)){
                if($file!='.' && $file!='..'){
                    echo '<a href = " '.$directory. '/'.$file.'">'.$file.'</a><br>';
                }
            }
            ?>
            </body>
    
</html>
