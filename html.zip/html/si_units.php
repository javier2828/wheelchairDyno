<?php
shell_exec('rm units.txt'); // remove units if si is selected from main menu
shell_exec('echo "1" >> units.txt'); // change state to si
header('Location: index.html'); // go back to main page
?>
