<?php
shell_exec('rm units.txt'); // remove units file if imperial units are selected
shell_exec('echo "0" >> units.txt'); // save units as imperial state
header('Location: index.html'); // back to main
?>
